outfile = File.new("myfile.txt","w")
outfile.print("Hello, world\n")
outfile.puts("Goodbye, world!")
outfile.print(100)
outfile.print(2*2)
outfile.close