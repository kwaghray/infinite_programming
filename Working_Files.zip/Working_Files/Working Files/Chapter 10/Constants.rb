module Constants
   PI = 3.14159
   E = 2.71828
   GR = 1.61803
end