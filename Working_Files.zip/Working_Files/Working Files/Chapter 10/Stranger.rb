module Stranger
   def Stranger.greeting
      return "How are you?"
   end
end