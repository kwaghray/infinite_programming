module Familiar
   def Familiar.greeting
      return "What's up?"
   end
end