nums = [10,9,2,23,1,34,3]
min = 1000
for i in nums
   if i < min
      min = i
   end
end
print("The minimum value is ", min)