nums = [1,2,3,4,5]
for i in nums
   print(i, i*i)
end